package petPals;

public class peluqueria {

}
